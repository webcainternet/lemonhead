<?php
// Heading
$_['heading_title']    = 'Bonuspunkte';

// Text
$_['text_total']       = 'Auftragssumme';
$_['text_success']     = 'Erfolgreich: Bonuspunkte geändert!';

// Entry
$_['entry_status']     = 'Status:';
$_['entry_sort_order'] = 'Reihenfolge:';

// Error
$_['error_permission'] = 'Warnung: Sie haben keine Berechtigung, um Bonuspunkten zu bearbeiten!';
?>