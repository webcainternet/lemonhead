<?php
$_['heading_title']      = 'Play.com (EU)';
$_['lang_heading_title'] = 'OpenBay Pro für Play.com';
?>