<?php
// Heading
$_['heading_title']    = 'Abholung';

// Text
$_['text_shipping']    = 'Versand';
$_['text_success']     = 'Erfolgreich: Versandart Abholung wurde aktualisiert';

// Entry
$_['entry_geo_zone']   = 'Geo Zone:';
$_['entry_status']     = 'Status:';
$_['entry_sort_order'] = 'Reihenfolge:';

// Error
$_['error_permission'] = 'Warnung: Sie haben keine Berechtigung, um die Versandart Abholung zu ändern!';
?>