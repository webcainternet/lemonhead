<?php
$_['lang_title']                    = 'OpenBay Pro für Amazon US | gespeicherte Angebote';
$_['lang_saved_listings']           = 'gespeicherte Angebote';
$_['lang_openbay']                  = 'OpenBay Pro';
$_['lang_overview']                 = 'Amazon US Überblick';
$_['lang_btn_return']               = 'Abbrechen';
$_['lang_description']              = 'Hier sehen Sie die Angebote, die lokal gespeichert sind und auf Amazon hochgeladen werden können. Bitte klicken Sie dazu auf Hochladen.';
$_['lang_actions_edit']             = 'Bearbeiten';
$_['lang_actions_remove']           = 'Löschen';
$_['lang_btn_upload']               = 'Hochladen';
$_['lang_name_column']              = 'Bezeichnung';
$_['lang_model_column']             = 'Modell';
$_['lang_sku_column']               = 'SKU';
$_['lang_amazonus_sku_column']        = 'Amazon Artikel SKU';
$_['lang_actions_column']           = 'Aktion';
$_['lang_uploaded_alert']           = 'Die gespeicherten Angebote wurden hochgeladen !';
$_['lang_delete_confirm']           = 'Sind Sie sicher ?';
?>