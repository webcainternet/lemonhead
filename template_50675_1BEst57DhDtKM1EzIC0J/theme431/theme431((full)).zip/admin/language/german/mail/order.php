<?php
// Text
$_['text_subject']      = '%s - Auftragsaktualisierung %s';
$_['text_order']        = 'Auftragsnummer:';
$_['text_date_added']   = 'Auftragsdatum:';
$_['text_order_status'] = 'Ihr Auftrag wurde auf folgenden Status geändert:';
$_['text_comment']      = 'Kommentare für Ihren Auftrag:';
$_['text_link']         = 'Bitte klicken Sie auf den Link unten, um Ihren Auftrag anzuzeigen:';
$_['text_footer']       = 'Bitte antworten Sie einfach auf diese E-Mail, falls Sie Fragen haben.';
?>