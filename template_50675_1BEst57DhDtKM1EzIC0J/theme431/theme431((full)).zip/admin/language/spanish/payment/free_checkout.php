<?php
// Heading
$_['heading_title']      = 'Compra gratis';

// Text
$_['text_payment']       = 'Pago';
$_['text_success']       = 'Éxito: has modificado el módulo de pago compra gratis!';

// Entry
$_['entry_order_status'] = 'Estado del pedido:';
$_['entry_status']       = 'Estado:';
$_['entry_sort_order']   = 'Orden de aparición:';

// Error
$_['error_permission']   = 'Cuidado: No tienes permisos para modificar el pago compra gratis!';
?>
