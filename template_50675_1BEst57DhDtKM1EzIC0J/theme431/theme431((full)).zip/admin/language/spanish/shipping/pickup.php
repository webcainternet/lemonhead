<?php
// Heading
$_['heading_title']    = 'Recogida en tienda';

// Text 
$_['text_shipping']    = 'Envío';
$_['text_success']     = 'Éxito: has modificado el apartado recogida en tienda!';

// Entry
$_['entry_geo_zone']   = 'Zona Geográfica:';
$_['entry_status']     = 'Estado:';
$_['entry_sort_order'] = 'Orden de aparición:';

// Error
$_['error_permission'] = 'Cuidado: No tienes permisos para modificar el apartado recogida en tienda!';
?>