<?php
// Text
$_['text_subject']      = '%s - Actualización de pedido %s';
$_['text_order']        = 'ID del pedido:';
$_['text_date_added']   = 'Fecha del pedido:';
$_['text_order_status'] = 'Tu pedido ha sido actualizado al siguiente estado:';
$_['text_comment']      = 'Las notas de tu pedido son:';
$_['text_link']         = 'Para ver tu pedido haz click en el enlace inferior:';
$_['text_footer']       = 'Por favor contesta a este email si tienes alguna duda.';
?>
