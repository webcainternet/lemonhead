<?php
// Text
$_['text_footer'] = '<a href="http://www.opencart.com">OpenCart</a> &copy; 2009-' . date('Y') . ' Todos los derechos reservados.<br />Versión %s';
?>
