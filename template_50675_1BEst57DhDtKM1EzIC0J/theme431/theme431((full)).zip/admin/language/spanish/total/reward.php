<?php
// Heading
$_['heading_title']    = 'Puntos de recompensa';

// Text
$_['text_total']       = 'Totales del pedido';
$_['text_success']     = 'Éxito: has modificado el total de puntos recompensa!';

// Entry
$_['entry_status']     = 'Estado:';
$_['entry_sort_order'] = 'Orden de aparición:';

// Error
$_['error_permission'] = 'Cuidado: No tienes permisos para modificar el total de puntos de recompensa!';
?>